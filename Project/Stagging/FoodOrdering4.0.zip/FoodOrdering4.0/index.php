<?php
header('Location: Auth/Login.php')
?>