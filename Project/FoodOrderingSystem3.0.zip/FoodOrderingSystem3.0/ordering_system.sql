-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2022 at 09:36 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ordering_system`
--
CREATE DATABASE IF NOT EXISTS `ordering_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ordering_system`;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(9) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float(8,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `price`, `image`, `category`) VALUES
(1, 'Nasi Lemak Ayam', 2.50, 'Nasi Lemak Ayam_1.jpg', 1),
(2, 'Nasi Goreng Ayam', 7.50, 'Nasi Goreng Ayam_1.png', 1),
(3, 'Nasi Bujang', 2.50, 'Nasi Bujang_1.png', 1),
(4, 'Mee Goreng', 5.50, 'Mee Goreng_2.png', 2),
(5, 'Nasi Biriyani Ayam', 7.50, NULL, 2),
(6, 'Thosai', 1.15, '', 2),
(7, 'Nasi Goreng ', 6.50, '', 3),
(8, 'Chili Kering Ayam', 7.50, NULL, 3),
(9, 'Wan Tan Mee', 5.50, NULL, 3),
(10, 'Chicken Chop', 9.50, NULL, 4),
(11, 'Spaghetti', 8.50, NULL, 4),
(12, 'Chicken Pepperoni Pizza', 15.50, NULL, 4),
(13, 'Milo Ais', 2.50, NULL, 5),
(14, 'Mango Juice', 4.50, NULL, 5),
(15, 'Extrajos Anggur', 3.50, NULL, 5),
(18, 'Nasi Ayam', 8.50, 'Nasi Ayam.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(9) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `username` varchar(255) NOT NULL,
  `menuID` varchar(99) NOT NULL,
  `category` varchar(255) NOT NULL,
  `total` float(9,2) NOT NULL,
  `receipt` varchar(255) DEFAULT NULL,
  `status` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `datetime`, `username`, `menuID`, `category`, `total`, `receipt`, `status`) VALUES
(12, '2022-03-16 21:13:34', 'Test', '3|2|3', '1|1|1', 12.50, NULL, 0),
(13, '2022-03-17 05:54:31', 'Yuga', '14|3', '5|1', 7.00, '13_Yuga.jpg', 1),
(19, '2022-03-19 04:12:47', 'Yuga', '3|6|2', '1|2|1', 11.15, NULL, 0),
(20, '2022-03-19 08:14:56', 'Yuga', '2|4|10', '1|2|4', 22.50, NULL, 0),
(21, '2022-03-19 08:26:36', 'Owner', '7|2|3', '3|1|1', 16.50, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ordersub`
--

CREATE TABLE `ordersub` (
  `id` int(9) NOT NULL,
  `orderID` int(9) NOT NULL,
  `menu` int(9) NOT NULL,
  `category` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordersub`
--

INSERT INTO `ordersub` (`id`, `orderID`, `menu`, `category`) VALUES
(1, 20, 2, 1),
(2, 20, 4, 2),
(3, 20, 10, 4),
(4, 21, 7, 3),
(5, 21, 2, 1),
(6, 21, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `id` int(9) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`id`, `name`, `category`, `picture`) VALUES
(1, 'Melayu & Thailand', 'Melayu', 'test'),
(2, 'Indian Cuisine', 'Indian', 'Test'),
(3, 'Hong Cheng Food', 'Chinese', 'Test'),
(4, 'Albert Western Cafe', 'Western', 'Test'),
(5, 'Ali Drinks', 'Drinks', 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `Hp` varchar(99) NOT NULL,
  `type_user` varchar(255) NOT NULL,
  `ownerCategory` int(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `name`, `email`, `Hp`, `type_user`, `ownerCategory`) VALUES
('Admin', '1234', 'Admin2', 'admin2@gmail.com', '60149165192', 'Admin', NULL),
('Yuga', '1234', 'Yugathes Subramaniam', 'yugathesyuga@gmail.com', '60149165192', 'User', NULL),
('Owner', '1234', 'Owner', 'owner@gmail.com', '60163498231', 'Owner', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordersub`
--
ALTER TABLE `ordersub`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderID` (`orderID`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `ordersub`
--
ALTER TABLE `ordersub`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `shop`
--
ALTER TABLE `shop`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ordersub`
--
ALTER TABLE `ordersub`
  ADD CONSTRAINT `ordersub_ibfk_1` FOREIGN KEY (`orderID`) REFERENCES `orders` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
