<?php
ob_start();
session_start();?>
<!DOCTYPE html>
<?php
if(isset($_SESSION['1login_intro'])){
?>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Permintaan Cuti | Sistem eCuti</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="../assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">  <!--  jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

<!-- Bootstrap Date-Picker Plugin -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="../assets/css/argon.css?v=1.2.0" type="text/css">
</head>

<body class="bg-info">
  <!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
          <img src="../assets/img/brand/blue.png" class="navbar-brand-img" alt="...">
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="home.php">
                <i class="ni ni-world text-dark "></i>
                <span class="nav-link-text font-weight-bold text-dark">Profil Saya</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="permintaan.php">
                <i class="ni ni-bullet-list-67 text-info"></i>
                <span class="nav-link-text font-weight-bold text-info">Permintaan Cuti</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="status.php">
                <i class="ni ni-money-coins text-dark"></i>
                <span class="nav-link-text font-weight-bold text-dark">Status Permintaan</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="senarai.php">
                <i class="ni ni-user-run text-dark"></i>
                <span class="nav-link-text font-weight-bold text-dark">Senarai Permintaan Cuti</span>
              </a>
            </li>
         
          </ul>
          <!-- Divider -->
          <hr class="my-3">
          <!-- Heading -->
          
          <!-- Navigation -->
          <ul class="navbar-nav mb-md-3">
            
            <li class="nav-item">
              <a class="nav-link active active-pro" href="along.php">
                <i class="ni ni-trophy text-dark"></i>
                <span class="nav-link-text">Sistem eCuti</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-dark border-bottom">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Search form -->
          <form class="navbar-search navbar-search-light form-inline mr-sm-3" id="navbar-search-main">
            <div class="form-group mb-0">
              <div class="input-group input-group-alternative input-group-merge">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fas fa-search"></i></span>
                </div>
                <input class="form-control" placeholder="Search" type="text">
              </div>
            </div>
            <button type="button" class="close" data-action="search-close" data-target="#navbar-search-main" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </form>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </div>
            </li>
            <li class="nav-item d-sm-none">
              <a class="nav-link" href="#" data-action="search-show" data-target="#navbar-search-main">
                <i class="ni ni-zoom-split-in"></i>
              </a>
            </li>
            
              <div class="dropdown-menu dropdown-menu-lg dropdown-menu-dark bg-default  dropdown-menu-right ">
                <div class="row shortcuts px-4">
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-red">
                      <i class="ni ni-calendar-grid-58"></i>
                    </span>
                    <small>Calendar</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-orange">
                      <i class="ni ni-email-83"></i>
                    </span>
                    <small>Email</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-info">
                      <i class="ni ni-credit-card"></i>
                    </span>
                    <small>Payments</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-green">
                      <i class="ni ni-books"></i>
                    </span>
                    <small>Reports</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-purple">
                      <i class="ni ni-pin-3"></i>
                    </span>
                    <small>Maps</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-yellow">
                      <i class="ni ni-basket"></i>
                    </span>
                    <small>Shop</small>
                  </a>
                </div>
              </div>
            </li>
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
            <li class="nav-item dropdown">
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo $_SESSION['1login_intro'];?></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Assalamualaikum!</h6>
                </div>
                <a href="profile.php" class="dropdown-item">
                  <i class="ni ni-single-02"></i>
                  <span>My profile</span>
                </a>
                <a href="settings.php" class="dropdown-item">
                  <i class="ni ni-settings-gear-65"></i>
                  <span>Settings</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="logout.php" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>
     <!-- Header -->
    <!-- Header -->
    <div class="header bg-info pb-6">
      <div class="container-fluid">
         <br><h2> </h2><br>
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-xl-3 col-md-6">
             
            </div>
            <div class="col-xl-3 col-md-6">
             
            </div>
            <div class="col-xl-3 col-md-6">
             
            </div>
            <div class="col-xl-3 col-md-6">
             
            </div>
          </div>
        </div>
      </div>
    </div>
     <!-- Page content -->
    <div class="container-fluid mt--6 bg-info">
      <div class="row">
        <div class="col-xl-12">
        <div class="row">
        <div class="col">
          <div class="card bg-default shadow">
            <div class="card-header bg-transparent border-0">
              <h3 class="text-white mb-0">Permintaan Cuti Baharu</h3>
            </div>
             <div class="row">
            <div class="col-xl-3" style="padding-left: 30px;">
         
          
          <div class="form-group">
  <label for="sel1" class="h5 text-white mb-2" >Jenis Cuti</label>
  <select class="form-control" id="sel1">
    <option value="Sila Pilih">Sila Pilih</option>
    <option value="Annual Leave">Annual Leave</option>
 <option value="Maternity Leave">Maternity Leave</option>
  <option value="Paternity Leave">Paternity Leave</option>
   <option value="Compassionate Leave">Compassionate Leave</option>
    <option value="Medical Leave">Medical Leave</option>
     <option value="Emergency Leave">Emergency Leave</option>
      <option value="Replacement Leave">Replacement Leave</option>
      <option value="Carry Forward Leave">Carry Forward Leave</option>
  </select>
  
  
</div>


 <div class="form-group">
  <label for="sel1" class="h5 text-white mb-2" >Tempoh</label>
  <select class="form-control" id="select" onchange="ShowDiv(this.value)">
      <option value="Sila Pilih">Sila Pilih</option>
    <option value="1">Separuh Hari</option>
    <option value="2">Seharian</option>
    <option value="3">Lebih Sehari</option>
  </select>
</div><br><br>
 <div class="form-group"> <!-- Submit button -->
        <button class="btn btn-primary " name="submit" type="submit">Submit</button>
      </div>
</div>

<!----Start of js panels------>
<div class="col-xl-3" id="seharian">
 <div class="form-group"> <!-- Date input -->
        <label for="date" class="h5 text-white mb-2">Tarikh</label>
        <input class="form-control" id="date" name="date" placeholder="Sila Pilih" type="date"/>
      </div>
      
      
   <div class="form-group"> <!-- Date input -->
        <label for="date" class="h5 text-white mb-2">Dokumen Sokongan</label>
<input id="input-b2" name="input-b2" type="file" class="file" data-show-preview="false">
</div>

</div>


<!----Start of js panels------>
<div class="col-xl-3" id="separuh">
 <div class="form-group"> <!-- Date input -->
        <label for="date" class="h5 text-white mb-2">Tarikh</label>
        <input class="form-control" id="date" name="date" placeholder="Sila Pilih" type="date"/>
      </div>
      
       <div class="form-group">
  <label for="sel1" class="h5 text-white mb-2" >Masa</label>
  <select class="form-control" id="selectx" onchange="ShowDiv(this.value)">
      <option value="Sila Pilih">Sila Pilih</option>
    <option value="1">Sebelum Lunch Break</option>
    <option value="2">Selepas Lunch Break</option>
  </select>
</div>


   <div class="form-group"> <!-- Date input -->
        <label for="date" class="h5 text-white mb-2">Dokumen Sokongan (Jika Ada)</label>
<input id="input-b2" name="input-b2" type="file" class="file" data-show-preview="false">
</div>

</div>


<!----Start of js panels------>
<div class="col-xl-3" id="lama">
 <div class="form-group"> <!-- Date input -->
        <label for="date" class="h5 text-white mb-2">Tarikh Bermula</label>
        <input class="form-control" id="date" name="date" placeholder="Sila Pilih" type="date"/>
      </div>
      
       <div class="form-group"> <!-- Date input -->
        <label for="date" class="h5 text-white mb-2">Tarikh Berakhir</label>
        <input class="form-control" id="date" name="date" placeholder="Sila Pilih" type="date"/>
      </div>
      
      
      
   <div class="form-group"> <!-- Date input -->
        <label for="date" class="h5 text-white mb-2">Dokumen Sokongan</label>
<input id="input-b2" name="input-b2" type="file" class="file" data-show-preview="false">
</div>

</div>

 <div class="col-xl-5" id="sebab">
           <div class="form-group">
    <label for="exampleFormControlTextarea1" class="h5 text-white mb-2">Sebab</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="7"></textarea>
  </div>
         </div>
      
      </div> </div>

     <!-- Form code ends --> 



 
 
       
      </div>
      
       </div>
        </div>
      </div>

      
      <!-- Footer -->
      <footer class="footer pt-0 bg-info">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-6">
            <div class="copyright text-center  text-lg-left  text-white">
              &copy; 2020 <a href="https://thesouthernfinance.com/" class="font-weight-bold ml-1 text-white" target="_blank">The Southern Finance</a>
            </div>
          </div>
          <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end text-dark"> 
              <li class="nav-item text-dark">
                <a href="https://www.zulabs.com.my" class="nav-link" target="_blank">Zulabs Digital</a>
              </li>
              <li class="nav-item text-dark">
                <a href="https://thesouthernfinance.com/official-partners/" class="nav-link" target="_blank">Official Partners</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="../assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="../assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
   <script>
      document.addEventListener("DOMContentLoaded", function(event) {
   document.querySelectorAll('img').forEach(function(img){
  	img.onerror = function(){this.style.display='none';};
   })
});
  </script>
  
  <script>
  window.onload = function() {
  document.getElementById('seharian').style.display = 'none';
   document.getElementById('separuh').style.display = 'none';
    document.getElementById('lama').style.display = 'none';
    document.getElementById('sebab').style.display = 'none';
};
  </script>
  
  <script>
      
      $(document).ready(function(){

     $('#select').change(function(){

     if($(this).val()=="1") {
        $("#seharian").hide();
         $("#separuh").show();
          $("#lama").hide();
          $("#sebab").show();

     }
     else if($(this).val()=="2") {
        $("#seharian").show();
         $("#separuh").hide();
          $("#lama").hide();
          $("#sebab").show();
     }
     else if($(this).val()=="3") {
        $("#seharian").hide();
         $("#separuh").hide();
          $("#lama").show();
          $("#sebab").show();
     } else {}

  });

});
      
  </script>
  
  <script>
    $(document).ready(function(){
      var date_input=$('input[name="date"]'); //our date input has the name "date"
      var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
      var options={
        format: 'mm/dd/yyyy',
        container: container,
        todayHighlight: true,
        autoclose: true,
      };
      date_input.datepicker(options);
    })
</script>
</body>
</html>
<?php   }
else{   header('Location:index.php');}
?>