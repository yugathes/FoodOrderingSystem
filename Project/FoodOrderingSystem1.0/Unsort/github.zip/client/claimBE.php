<?php
//ob_start();
session_start();
    include "../admin/connection.php";
    
    date_default_timezone_set('Asia/Kuala_Lumpur');
    if (isset($_POST['claimBTN'])) {
        $prizeID = $_POST['pID'] ; 
        $claimLot = mysqli_real_escape_string($link,$_POST['pLot']);
        $tName = $_SESSION['1login_client'] ;
        $ordID= "";
        $status= "Pending";
        $datetime = date('Y-m-d G:i:s ', time());
        $time = new DateTime($datetime);
        $maxLot = $_POST['maxLot'] ;
        
    if($maxLot >= $claimLot){
	    $queryUpdate = "UPDATE prize SET total=(total+1) WHERE prizeID = '".$prizeID."'";
	    $resultUpdate = mysqli_query($link,$queryUpdate);
	    
	    $CqueryUpdate = "UPDATE client SET priceL=(priceL-$claimLot) WHERE cName = '".$tName."'";
	    $CresultUpdate = mysqli_query($link,$CqueryUpdate);
	    
	    $queryInsert = "INSERT INTO pOrder (ordID, przID, userName, datetime, status)
	                    VALUES ('$ordID', '$prizeID', '$tName', '$datetime', '$status')";
        $resultInsert = mysqli_query($link,$queryInsert);
        
        $PqueryInsert = "INSERT INTO priceLot (logID, usrName, description, priceLot, DateTime)
	                    VALUES ('', '$tName', '$prizeID', '$claimLot', '$datetime')";
        $PresultInsert = mysqli_query($link,$PqueryInsert);
    	
    	if (!$resultUpdate)
    	{
    		die ("Error: ".mysqli_error($link));
    	}		
    	else 
    	{
    	    if (!$resultInsert)
        	{
        		die ("Error: ".mysqli_error($link));
        	}
        	else
        	{
                if (!$CresultUpdate)
                {
                    die ("Error: ".mysqli_error($link));
                }
                else
                {
                    if (!$PresultInsert)
                	{
                		die ("Error: ".mysqli_error($link));
                	}
                	else
                	{
            	        echo '<script type="text/javascript">
            			window.onload = function () 
            			{ 
            			confirm("Prize Claimed Successfully.\nWe will contact you soon.");
            			open("claimprizes.php","_top");
            			}
            			</script>';
                	}
    	        }
    	        
        	}
	   }
    }
    else
                {   $valLot =abs($maxLot - $claimLot);
        	        echo '<script type="text/javascript">
        			window.onload = function () 
        			{ 
        			var val = ' . $valLot . ';
        			alert("Claim Failed.\nYou need : " + val + " to claim");
        			open("claimprizes.php","_top");
        			}
        			</script>';
    	        }
}
 if (isset($_POST['BTN'])) {
    header("Location: claimprizes.php");
     
 }
?>