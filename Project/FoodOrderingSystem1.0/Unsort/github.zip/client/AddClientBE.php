<?php
ob_start();
session_start();

// initializing variables
$uID = "";
$trdLot= "";
$name = "";
$password = "";
$username ="";
$number    = "";
$email    = "";
$tName    = "";
$iname    = "";
$lytrank    = "";
$fbsid    = "";
$xmid    = "";
$tifiaid    = "";
$liteid    = "";
$aximid    = "";
$address = "";
$status = "0";
$errors = array(); 

// connect to the database
$ds = mysqli_connect('localhost', 'thesouth_yuga', '~6C^h8K3W+k1', 'thesouth_prizelot');

// REGISTER USER
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
if (isset($_POST['AddClient'])) {
 

  // receive all input values from the form
	$name = mysqli_real_escape_string($ds, $_POST['name']);
	$email = mysqli_real_escape_string($ds, $_POST['email']);
	$password = mysqli_real_escape_string($ds, $_POST['password']);
	$number = mysqli_real_escape_string($ds, $_POST['number']);
	$tName = mysqli_real_escape_string($ds, $_POST['tName']);
	$iname = mysqli_real_escape_string($ds, $_POST['iName']);
	$lytrank = mysqli_real_escape_string($ds, $_POST['lytRank']);
	$fbsid    = mysqli_real_escape_string($ds, $_POST['fbsID']);
	$xmid    = mysqli_real_escape_string($ds, $_POST['xmID']);
	$tifiaid    = mysqli_real_escape_string($ds, $_POST['tifiaID']);
	$liteid    = mysqli_real_escape_string($ds, $_POST['liteID']);
	$aximid    = mysqli_real_escape_string($ds, $_POST['aximID']);
	$address = mysqli_real_escape_string($ds, $_POST['address']);
  
  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($name)) { array_push($errors, "Full Name is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password)) { $password="ilovesf123"; }
  if (empty($tName)) { array_push($errors, "Trading Name is required"); }
  if (empty($lytrank)) { array_push($errors, "Trading Name is required"); }
  if (empty($address)) { array_push($errors, "Address is required"); }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM users WHERE tName='$tName' OR email='$email' LIMIT 1";
  $result = mysqli_query($ds, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  if ($user) { // if user exists
    if ($user['tName'] === $tName) {
      array_push($errors, "name already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }
  

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
echo "enter";
  	$query = "INSERT INTO users(usrID, name, Hp, email, password, tName, iName, lytRank, fbsID, xmID, tifiaID, liteID, aximID, tLots, address, datetime, status) 
  			  VALUES('$uID', '$name', '$number', '$email', '$password', '$tName', '$iname', '$lytrank', '$fbsid', '$xmid', '$tifiaid', '$liteid', '$aximid', '$trdLot', '$address',NOW(),'$status')";
    $queryC = "INSERT INTO client(cName, fbsL, xmL, tifiaL, liteL, aximL, totalL, priceL, leaderB) 
  			  VALUES ('$tName', '', '', '', '', '', '$trdLot', '', '')";  			  
  	$result = mysqli_query($ds, $query);
  	$resultC = mysqli_query($ds, $queryC);
  	if (!$result)
	{
	    $fail = "Please Check Registration.";
        echo "<script type='text/javascript'>alert('$fail');
	    document.location='index.php';
	    </script>";
	}
	else
	{
	    if (!$resultC)
    	{
            die ("Invalid Query - get Items List: ". mysqli_error($ds));
    	}
	    else
	    {
	     $sucess = "Registration anda berjaya. Sila login dengan menggunakan Email atau TraderName anda untuk proses verifikasi.";
	    echo "<script type='text/javascript'>alert('$sucess');
	    document.location='index.php';
	    </script>";
	    }
	}
	
  }
  
}

