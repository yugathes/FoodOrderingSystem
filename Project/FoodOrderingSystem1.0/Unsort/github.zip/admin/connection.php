<?php
$link=mysqli_connect('localhost', 'thesouth_yuga', '~6C^h8K3W+k1', 'thesouth_cuti');
// Check connection
if (mysqli_connect_errno())
{
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      die();
}

?>