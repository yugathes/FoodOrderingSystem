<?php
include "connection.php";
$client= $_GET['id'];
$clientN= $_GET['name'];
$intro = $_GET['usrID'];
$event = $_GET['eID'];
$order = $_GET['ordID'];
$prize = $_GET['przID'];

if(isset($client)){
	$queryDelete = "DELETE FROM users WHERE usrID = '".$client."'";
	$resultDelete = mysqli_query($link,$queryDelete);
	if (!$resultDelete)
	{
		die ("Error: ".mysqli_error($link));
		}		
	else {
	    $queryDeleteC = "DELETE FROM client WHERE cName = '".$clientN."'";
    	$resultDeleteC = mysqli_query($link,$queryDeleteC);
    	if (!$resultDeleteC)
    	{
    		die ("Error: ".mysqli_error($link));
    		}		
    	else {
    		header("Location: clients.php");
    	}
	}
}
if(isset($clientN)){
	
}
if(isset($event)){
	$queryDelete = "DELETE FROM event WHERE eventID = '".$event."'";
	$resultDelete = mysqli_query($link,$queryDelete);
	if (!$resultDelete)
	{
		die ("Error: ".mysqli_error($link));
		}		
	else {
		header("Location: eventsmanagement.php");
	}
}
if(isset($order)){
	$queryDelete = "DELETE FROM pOrder WHERE ordID = '".$order."'";
	$resultDelete = mysqli_query($link,$queryDelete);
	if (!$resultDelete)
	{
		die ("Error: ".mysqli_error($link));
		}		
	else {
		header("Location: orders.php");
	}
}
if(isset($prize)){
	$queryDelete = "DELETE FROM prize WHERE prizeID = '".$prize."'";
	$resultDelete = mysqli_query($link,$queryDelete);
	if (!$resultDelete)
	{
		die ("Error: ".mysqli_error($link));
		}		
	else {
		header("Location: prizelist.php");
	}
}
if(isset($intro)){
	$queryDelete = "DELETE FROM introducer WHERE usrID = '".$intro."'";
	$resultDelete = mysqli_query($link,$queryDelete);
	if (!$resultDelete)
	{
		die ("Error: ".mysqli_error($link));
		}		
	else {
		header("Location: introducers.php");
	}
}
?>