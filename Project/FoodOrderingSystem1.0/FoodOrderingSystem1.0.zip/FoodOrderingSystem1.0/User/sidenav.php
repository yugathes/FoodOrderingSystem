<?php
$activePage = basename($_SERVER['PHP_SELF'], ".php");

?>
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
          <img src="../assets/img/brand/blue.png" class="navbar-brand-img" alt="...">
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="home.php">
                <i class="ni ni-world <?php if ($activePage=="home") {echo "text-primary"; } else  {echo "text-dark";}?> "></i>
                <span class="nav-link-text font-weight-bold <?php if ($activePage=="home") {echo "text-primary"; } else  {echo "text-dark";}?>">My Profile</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="permintaan.php">
                <i class="ni ni-bag-17 <?php if ($activePage=="permintaan") {echo "text-primary"; } else  {echo "text-dark";}?>"></i>
                <span class="nav-link-text font-weight-bold <?php if ($activePage=="permintaan") {echo "text-primary"; } else  {echo "text-dark";}?>">Leave Application</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="status.php">
                <i class="ni ni-money-coins <?php if ($activePage=="status") {echo "text-primary"; } else  {echo "text-dark";}?>"></i>
                <span class="nav-link-text font-weight-bold <?php if ($activePage=="status") {echo "text-primary"; } else  {echo "text-dark";}?>">Application Status</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="list_application.php">
                <i class="ni ni-user-run <?php if ($activePage=="list_application") {echo "text-primary"; } else  {echo "text-dark";}?>"></i>
                <span class="nav-link-text font-weight-bold <?php if ($activePage=="list_application") {echo "text-primary"; } else  {echo "text-dark";}?>">Application List</span>
              </a>
            </li>


          </ul>
          <!-- Divider -->
          <hr class="my-3">
          <!-- Heading -->
          
          <!-- Navigation -->
          <ul class="navbar-nav mb-md-3">
            
            <li class="nav-item">
              <a class="nav-link active active-pro" href="along.php">
                <i class="ni ni-trophy text-dark"></i>
                <span class="nav-link-text">Sistem eCuti</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>