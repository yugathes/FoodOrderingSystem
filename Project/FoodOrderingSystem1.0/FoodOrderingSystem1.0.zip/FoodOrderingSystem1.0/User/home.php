<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);
session_start();?>
<!DOCTYPE html>
<?php
if(isset($_SESSION['1login_client'])){
   $usrName = $_SESSION['1login_client'];
?>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>My Profile | Sistem eCuti</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="../assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="../assets/css/argon.css?v=1.2.0" type="text/css">
</head>

<body>
   <!-- Sidenav -->

  <?php include('sidenav.php');?>
 <!-- Main content -->
 
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <?php include('topnav.php');?>
    <!-- Header -->
     <?php
    include "../admin/connection.php";
    $count = 0;
    
    $UqueryGet = "select * from users WHERE username = '".$usrName."'";	
    $UresultGet = mysqli_query($link,$UqueryGet);
    if(!$UresultGet){die ("Invalid Query - get Items List: ". mysqli_error($link));}
    else{while($row= mysqli_fetch_array($UresultGet, MYSQLI_BOTH)){ 
        $userID=$row['usrID'];
        ?>
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <br>
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-xl-3 col-md-6">
             
            </div>
            <div class="col-xl-3 col-md-6">
             
            </div>
            <div class="col-xl-3 col-md-6">
             
            </div>
            <div class="col-xl-3 col-md-6">
             
            </div>
          </div>
        </div>
      </div>
    </div>
  
       <!-- Page content -->
    <div class="container-fluid mt--6 bg-primary">
      <div class="row">
        <div class="col-xl-7">
          <div class="card bg-default">
            <div class="card-header bg-transparent">
              <div class="row align-items-center">
                <div class="col">
                  <h6 class="text-light text-uppercase ls-1 mb-1">Sistem eCuti</h6>
                  <h5 class="h2 text-white mb-0">My Profile</h5>
                </div>
                <div class="col">
                  <ul class="nav nav-pills justify-content-end">
                
                  </ul>
                </div>
              </div>
            </div>
                <!-- Chart wrapper -->
                <div class="card-body">
                <form action="home.php" method="POST">
                    <?php include('errors.php'); ?>
  <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2" >Full Name *</label>
    <input type="text" class="form-control text-dark" id="exampleFormControlInput1" name="name" placeholder="" value="<?php echo $row['name'];?>"required>
  </div>

  <div class="row">

  <div class="col-xl-6">
  <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2" >Phone No. *</label>
    <input type="text" class="form-control text-dark" id="exampleFormControlInput1" name="Hp" placeholder="" value="<?php echo $row['Hp'];?>" required>
  </div>
  
    <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2" >Email *</label>
    <input type="text" class="form-control text-dark" id="exampleFormControlInput1" name="email" placeholder="" value="<?php echo $row['email'];?>" required>
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2" >Password </label>
    <input type="password" class="form-control text-dark" id="exampleFormControlInput1" name="pswd1" placeholder="" value="<?php echo $row['password'];?>">
  </div>
  
    <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2" >Date Joined </label>
    <input type="text" class="form-control text-dark" id="exampleFormControlInput1" name="pswd1" placeholder="" value="<?php echo $row['date'];?>" disabled>
  </div>


</div>

<div class="col-xl-6">
  <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2" >Username</label>
    <input type="text" class="form-control text-dark" id="exampleFormControlInput1" name="username" placeholder="" value="<?php echo $row['username'];?>" disabled>
    <input type="hidden" name="username" value="<?php echo $row['username'];?>">
  </div>
<?php
    $JqueryGet = "select * from jabatan order by jID";	
	$JresultGet = mysqli_query($link,$JqueryGet);
	if(!$JresultGet)
	{
		die ("Invalid Query - get Items List: ". mysqli_error($link));
	}
	else
	{
?>
  <div class="form-group">
    <label for="exampleFormControlSelect1" class="h5 text-white mb-2" >Department *</label>
    <select class="form-control text-dark" id="exampleFormControlSelect1" name="jabatan" disabled>
<?php
    $department = $row['dept'];
    while($Jrow= mysqli_fetch_array($JresultGet, MYSQLI_BOTH))
	{
?>        
      <option value="<?php echo $Jrow['name'];?>" <?php if($Jrow['name']==$department) echo "selected"; ?> ><?php echo $Jrow['name'];?></option>
      <?php
		}
}
  ?>
    </select>
  </div>
  
    <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2" >Confirm Password</label>
    <input type="password" class="form-control text-dark" id="exampleFormControlInput1" name="pswd2" placeholder="" value="<?php echo $row['password'];?>" required>
  </div>
  
</div>
</div>
    <input class="btn btn-primary" type="submit" name="AddClient" value="Save">
</form>
<?php
}   }
if (isset($_POST['AddClient'])) {
    	$password = $_POST['pswd1'];
    	$password1 = $_POST['pswd2'];
    	
    	if(strcmp($password,$password1)==0)
    	{
    	    session_start();

            $name = "";
            $username ="";
            $number = "";
            $email = "";
            $errors = array(); 
            
            // connect to the database
            
$ds = mysqli_connect('localhost', 'globalel_cuti', 'Sz3759779', 'globalel_cuti');
            
            // REGISTER USER
            if (mysqli_connect_errno()) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
              exit();
            }
            else{
                
                // receive all input values from the form
            	$name = mysqli_real_escape_string($ds, $_POST['name']);
            	$email = mysqli_real_escape_string($ds, $_POST['email']);
            	$number = mysqli_real_escape_string($ds, $_POST['Hp']);
            	$username = mysqli_real_escape_string($ds, $_POST['username']);

                // form validation: ensure that the form is correctly filled ...
                // by adding (array_push()) corresponding error unto $errors array
                if (empty($name)) { array_push($errors, "Full Name is required"); }
                if (empty($email)) { array_push($errors, "Email is required"); }
                if (empty($number)) { array_push($errors, "Phone Number is required"); }
 
                $query = "UPDATE users SET
				name = '".$name."', 
				Hp = '".$number."', 
				email = '".$email."', 
				password = '".$password."' 
				WHERE username ='".$username."'";
          	    $result = mysqli_query($ds, $query);
              	if (!$result)
            	{
            	    $fail = "Please Check Update.";
                    echo "<script type='text/javascript'>alert('$fail');
            	    document.location='home.php';
            	    </script>";
            	}
            	else
            	{
            	   
            	    $sucess = "Client Update Sucessful.";
            	    echo "<script type='text/javascript'>alert('$sucess');
                	document.location='home.php';
                	</script>";
                	    
    	       }
            }
        }
        else{
    	    header("Location: dashboard.php");
    	}
    }
?>
    
  </div>

          </div>
        </div>

       <div class="col-xl-5">
          <div class="card">
            <div class="card-header bg-transparent">
              <div class="row align-items-center">
                <div class="col">
                  <h6 class="text-uppercase text-muted ls-1 mb-1">List</h6>
                  <h5 class="h3 mb-0">Leave Status</h5>
                </div>
              </div>
            </div>
            <div class="card-body">
              <!-- Chart -->
             <table class="table table-dark table-responsive">
                 
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">STATUS</th>
      <th scope="col">DATE</th>
    </tr>
  </thead>
  <tbody>
      <?php
    $count = 0;
    
    $UcqueryGet = "select * from Cuti WHERE sUsername = '".$usrName."'";	
    $UcresultGet = mysqli_query($link,$UcqueryGet);
    if(!$UcresultGet){die ("Invalid Query - get Items List: ". mysqli_error($link));}
    else{while($Crow= mysqli_fetch_array($UcresultGet, MYSQLI_BOTH)){ 
        
        ?>
    <tr>
      <th scope="row">000<?php echo $Crow['id'];?></th>
      <td><?php if($Crow['management']==1 AND $Crow['admin']==1) echo "Approved"; else echo "Processing";?></td>
      <td><?php echo $Crow['date'];?></td>
    </tr>
    <?php } }?>

  </tbody>
</table>
<br><h3>Leave Balance</h3>
 
  <?php 
   $year  = date('Y');
  $sql="select 
  SUM( CASE WHEN (Cuti.LType = '1') THEN Cuti.number_days ELSE 0 END ) AS al, 
  SUM( CASE WHEN (Cuti.LType = '2') THEN Cuti.number_days ELSE 0 END ) AS mtl , 
  SUM( CASE WHEN (Cuti.LType = '3') THEN Cuti.number_days ELSE 0 END ) AS pl , 
  SUM( CASE WHEN (Cuti.LType = '4') THEN Cuti.number_days ELSE 0 END ) AS cl, 
  SUM( CASE WHEN (Cuti.LType = '5') THEN Cuti.number_days ELSE 0 END ) AS ml, 
  SUM( CASE WHEN (Cuti.LType = '7') THEN Cuti.number_days ELSE 0 END ) AS rl
 
 from Cuti 
 inner join users on users.usrID = Cuti.usrID 
 
  WHERE Cuti.usrID='$userID' AND Cuti.status = '2' AND  (YEAR(date(Cuti.Sdate))=$year  ) 
  GROUP BY  Cuti.usrID";
  
    // echo $sql;
  $result1 = mysqli_query($link, $sql);
  $rowcount=mysqli_num_rows($result1);
 $Crow= mysqli_fetch_array($result1, MYSQLI_BOTH);
$al = $Crow['al' ];
$mtl  = $Crow['mtl' ];
$pl  = $Crow['pl' ];
 $cl  = $Crow['cl' ];
 $ml  = $Crow['ml' ];
 $el =  $Crow['el' ];
$rl  = $Crow['rl' ];



 $sqlquery="select 
  jenisCuti.Annual AS aL,jenisCuti.Maternity AS mtL, jenisCuti.paternity AS pL,
 jenisCuti.compassionate AS cL, jenisCuti.medical AS mL,jenisCuti.replacement AS rL 
 from jenisCuti
  WHERE jenisCuti.usrID='$userID' ";
  
    // echo $sqlquery;
  $result2 = mysqli_query($link, $sqlquery);
  $row_count=mysqli_num_rows($result2);
 $row= mysqli_fetch_array($result2, MYSQLI_BOTH);
 $aL  = $row['aL' ];
  $mtL  = $row['mtL' ];
  $pL  = $row['pL' ];
 $cL  = $row['cL' ];
    $mL =  $row['mL' ];
    $rL  = $row['rL' ];
  ?>
    



    <div class="form-group">
    <label for="exampleFormControlInput1" class="h5 text-white mb-2">Leave Amount</label>
      <table class="table table-dark table-responsive">
                 
  <thead>
    <tr>
      <th scope="col">Type of Leave</th>
      <th scope="col">Amount</th>
    </tr>
  </thead>
  <tbody>
  <tr>
      <th scope="row">Annual </th>
      <td> <?php echo $al;?> of <?php echo $aL;?></td>
    </tr>
    <tr>
      <th scope="row">Maternity</th>
      <td> <?php echo $mtl;?> of <?php echo $mtL;?></td>
    </tr>
    <tr>
      <th scope="row">Paternity Leave</th>
      <td> <?php echo $pl;?> of <?php echo $pL ;?></td>
    </tr>
    <tr>
      <th scope="row">Compassionate Leave</th>
      <td> <?php echo $cl;?> of <?php echo $cL ;?></td>
    </tr>
    <tr>
      <th scope="row">Medical Leave </th>
      <td><?php echo $ml;?> of <?php echo  $mL ;?></td>
    </tr>
    <tr>
      <th scope="row">Replacement Leave </th>
      <td><?php echo $rl;?> of <?php echo  $rL ;?></td>
    </tr>
    </tbody>

    </table>
  </div>








            </div>
          </div>
        </div>
      </div>


      <div class="row">
      <div class="col-xl-8">
        
        </div>

      </div>
      <!-- Footer -->
      <footer class="footer pt-0 bg-primary">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-6">
            <div class="copyright text-center  text-lg-left  text-white">
              &copy; 2021 <a href="https://thesouthernfinance.com/" class="font-weight-bold ml-1 text-white" target="_blank">Global Elite Ventures</a>
            </div>
          </div>
          <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end text-white"> 
              <li class="nav-item text-dark">
                <a href="https://globalelite.com.my" class="nav-link" target="_blank">Homepage</a>
              </li>
              
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="../assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="../assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
</body>
</html>
<?php  }
else{   header('Location:index.php');}
?>