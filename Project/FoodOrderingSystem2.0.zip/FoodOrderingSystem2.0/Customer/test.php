<?php
session_start();
//if session exists
if(isset ($_SESSION["username"])) //call this function to check if session exists or not
{	?>
<!DOCTYPE html>
<html>
<head>
	<title>Products</title>
	<?php 	include "../Auth/connection.php";
		$direct = dirname($_SERVER['PHP_SELF']); $newD = explode("/", $direct);?>

    <title><?php echo end($newD);?> System</title>
    <link rel="stylesheet" type="text/css" href="../../CSS/topNav.css">
	<div class="topnav">
        <a <?php if (basename($_SERVER['PHP_SELF']) == "Products.php") echo "class='active'"?> href="Products.php">Menu</a>
		<div class="search-container">
		<input type="text" name="searchKey" id="searchKey"placeholder="Search for names" onkeyup="searchFunction()">
	</div>
	</div>
	<div class="auth">
<?php if(isset ($_SESSION["username"])) //session userid gets value from text field named userid, shown in user.php
    {?>
	    <a style="background-color:#6f7378;" href="../../index.html"> Logout </a>
<?php	
	}
	else
	{
	?>
	    <a style="background-color:#6f7378;" href="../../Auth/Login"> Login </a>
<?php
	}?>
		</div>
<style type="text/css">
	#searchKey {
		background-image: url('./searchicon.png'); 
		background-repeat: no-repeat;
		background-position: 10px 10px;
		padding: 12px 20px 12px 40px;
		border: 1px solid #dddddd;
		margin-top: 1px; 
	}
	table{
		font-family: arial, sans-serif;
		border-collapse: collapse;
		width: 90%;
	}
	td, th{
		border: 1px solid #dddddd;
		text-align: left;
		padding: 8px;
	}
	tr:nth-child(even) {
		background-color: #ddffff;

	}
</style>
</head>
<body>
<script type="text/javascript">
function loadDoc()
{
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("ProductList").innerHTML = this.responseText;
		}
	};
	xhttp.open("GET","http://localhost/Sony/Customer/requester/listProducts.php", true);
	xhttp.send();
}

function searchFunction() {
	var input, filter, table, tr, td, i, txtValue;
	input = document.getElementById("searchKey");
	filter = input.value.toUpperCase();
	table = document.getElementById("myTable");
	tr = table.getElementsByTagName("tr");
	for(i=0; i<tr.length; i++)
	{
		td = tr[i].getElementsByTagName("td")[1];
		if(td)
		{
			txtValue = td.textContent || td.innerText;
			if(txtValue.toUpperCase().indexOf(filter)> -1)
			{
				tr[i].style.display = "";
			}
			else
			{
				tr[i].style.display = "none";
			}
		}
	}
}
</script>

<h1 style="text-align:center;">SHOPOO</h1>
<h2 style="text-align:center;">Welcome To Shopoo Shop Online</h2>
<script>loadDoc();</script>
<P></P>
	

<center><table id='myTable'></center>
<div id="ProductList"></div>
</table>
</body>
</html>
<?php
}
else{
    echo "No session exists or session has expired. Please log in again ";
	echo "Page will be redirect in 2 seconds";
	header('Refresh: 2; ../../Auth/Login.php');
}				
?>