<?php
	include "../Auth/connection.php";
//Menu
if(isset($_POST["menu"])){
	$name = $_POST["name"];
	$price = $_POST["price"];
	$image = $_POST["image"];
	$category = $_POST["category"];
	$ID = $_POST["id"];
		
	$queryInsert = "UPDATE menu SET
		name = '".$name."',
		price = '".$price."',
		image = '".$image."',
		category = '".$category."'
		WHERE id = '$ID'";

	$resultInsert = mysqli_query($link,$queryInsert);
	if (!$resultInsert)
	{
		die ("Error: ".mysqli_error($link));
	}		
	else {
		echo '<script type="text/javascript">
			window.onload = function () 
			{ 
			alert("Food Menu been Updated...");
			open("Menu.php","_top");
			}
			</script>';

	}
}
//Users
if(isset($_POST["staffAdm"])){
	$email = $_POST["email"];
	$name =$_POST["name"];
	$Hp = $_POST["Hp"];
	$uID = $_POST["username"];
		
	$queryInsert = "UPDATE users SET
		name = '".$name."',
		email = '".$email."',
		Hp = '".$Hp."'
		WHERE username = '$uID'";

	$resultInsert = mysqli_query($link,$queryInsert);
	if (!$resultInsert)
	{
		die ("Error: ".mysqli_error($link));
	}		
	else {
		echo '<script type="text/javascript">
			window.onload = function () 
			{ 
			alert("Users Profile been Updated...");
			open("Users.php","_top");
			}
			</script>';

	}
}
//Staff
if(isset($_POST["staff"])){
	$email = $_POST["email"];
	$name =$_POST["name"];
	$Hp = $_POST["Hp"];
	$address = $_POST["address"];
	$uID = $_POST["username"];
		
	$queryInsert = "UPDATE users SET
		name = '".$name."',
		email = '".$email."',
		address = '".$address."',
		Hp = '".$Hp."'
		WHERE username = '$uID'";

	$resultInsert = mysqli_query($link,$queryInsert);
	if (!$resultInsert)
	{
		die ("Error: ".mysqli_error($link));
	}		
	else {
		echo '<script type="text/javascript">
			window.onload = function () 
			{ 
			alert("Staff Profile been Updated...");
			open("../Staff/home.php","_top");
			}
			</script>';

	}
}
?>